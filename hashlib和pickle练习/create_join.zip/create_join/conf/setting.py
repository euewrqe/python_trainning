import os

BASE_DIR=os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DB_DIR=os.path.join(BASE_DIR,"db")

MANAGER_USER="alex"
MANAGER_PASSWORD="e10adc3949ba59abbe56e057f20f883e"