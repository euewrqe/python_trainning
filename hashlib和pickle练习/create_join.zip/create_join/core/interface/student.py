def main():
    '''学生视角入口
    1, 查看个人成绩
    2, 查看课程信息
    3, 注册----注册一般放在student.json中
    '''
    pass